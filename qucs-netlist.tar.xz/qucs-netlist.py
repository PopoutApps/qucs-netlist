#! /usr/bin/python3
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Chris Rogers 31st March 2020, 2026

'''
Use .sch file for components as details are separate and .sim file 
for nets as there is no info about using the data in the .sch file.

The sch file does contain some net information but it needs other data like
the length of the component as it only specifies one location.
The .cir or .cdr files would be better as they contain it all. 
User would have to run Simulation > Save netlist or Save CDL netlist. Each format has pros and cons.


CGPT Structure, and GUI with v0.0.5 code.
Limit of 10 000 lines as safety factor so program does not get stuck in loop if 
there is a problem with the file.


Messages not complete

Install Flatpak and check Flatpak command



'''

import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path
import shlex, os, sys

version = 'v0.1.0'
nets = []         # list of nets ready for output (netlist in 0.0.5)
partlist = []     # array of parts with input against output component names
components = []   # list of valid parts ready for output (validparts in 0.0.5)
line = []         # 

warning = ''                    # rows of warning text
namehelp = 'qucs-netlist.hlp'          # help file
fileparts = 'qucs-netlist.dat'  # parts file
filesch = ''                    # schematic file
filesim = ''                    # simulation file
filenet = ''                    # output netlist file

#-------------------------------------------------------------------------------
def resourcePath(name: str) -> Path:
  import sys
  if hasattr(sys, '_MEIPASS'):
    base = Path(sys._MEIPASS)
  else:
    base = Path(__file__).resolve().parent
  return base / name

#-------------------------------------------------------------------------------
def read_text(path: Path) -> str:
  try:
    return path.read_text(encoding='utf-8')
  except UnicodeDecodeError:
    return path.read_text(encoding='latin-1')
   
#-------------------------------------------------------------------------------
def showHelp(root):
  global warning
  
  text = tk.Text(root, wrap='word', height = 15)
  text.pack(expand=True, fill='both') # remove for selection buttons
  text.pack(fill = 'both') # fill = 'x' if using output selection buttons
    
  scrollbar = tk.Scrollbar(root, command=text.yview)
  scrollbar.pack(side='right', fill='y')
  text.configure(yscrollcommand=scrollbar.set)
  help_path = resourcePath(namehelp)

  if help_path.exists():
    content = read_text(help_path)
    text.insert('1.0', content)
    text.config(state='disabled')  # read-only  
  else:
    messagebox.showinfo('Info', 'Failed to read help file.')
  
#-------------------------------------------------------------------------------
def loadParts():
    # Load partlist CGPT
    
  partlist_path = resourcePath(fileparts)
  if not partlist_path.exists():
    messagebox.showinfo('Error', 'Parts list file not found.')
    return False
    '''
    with open(partlist_path, 'r') as fpl:
        for line in fpl:
            line = line.strip()
            if line and not line.startswith('<'):
                partlist.append(shlex.split(line))
    '''

  with open(partlist_path, 'r') as fpl:
    try: 
      line = fpl.readline()
      if line[:14] == '<Qucs Partlist':
        line = ''; lineno = 0
        while line != [] and lineno < 1000: 
          lineno += 1
          line = fpl.readline() 
          line = shlex.split(line)
          if line != []:
            partlist.append(line)
      else:
        messagebox.showinfo('Error', 'Not a valid parts list file.')
        return False
    except:
      messagebox.showinfo('Error', 'Parts list file is empty')
      return False

    return True

#-------------------------------------------------------------------------------
def chooseFile(root):
  path = filedialog.askopenfilename(
    title='Select Qucs schematic',
    initialdir=str(Path.home()),
    filetypes=[('Qucs schematic', '*.sch')]
  )
  if path:
    return Path(path)
  else:
    root.destroy()
            
#-------------------------------------------------------------------------------
def checkComponents(): # Check parts and make list of valid ones in components # was parsesch in 0.0.5
  global components, warning
  
  #fields count 0 onwards
  if line[2] == '1': # component is active
      
    pfield9 = '' ; pfield11 = '' ; pfield13 = ''
    if len(line) > 9:
      pfield9 = line[9]
  
      if len(line) > 11:
        pfield11 = line[11]

        if len(line) > 13:
          pfield13 = line[13]

    pqucs = line[0]; pname = line[1]; pactive = line[2]
    if pqucs == 'Lib':
      pqucs = pfield9; pdetailA = pfield11 ; pdetailB = ''
    else:
      pqucs = line[0]; pdetailA = pfield9 ; pdetailB = pfield13 
  
    pdetail = '' ; foundpart = False

    for sublist in partlist:    
      if sublist[0] == pqucs:
        if sublist[1] == ''  or (sublist[1] == '9' and sublist[2] == pdetailA):
          foundpart = True
          components.append(pname)
          return('[\n'+pname+'\n'+sublist[3]+'\n'+pdetailA+'\n\n\n]\n')

        elif (sublist[1] == '13' and sublist[2] == pdetailB):
          foundpart = True
          components.append(pname)
          # whole set of lines for one component
          return('[\n'+pname+'\n'+sublist[3]+'\n'+pdetailB+'\n\n\n]\n') 

    if not foundpart:
      warning = warning + 'Unknown component type not converted: '+pname + ' ' + pqucs + '\n'
      return(None)

#-------------------------------------------------------------------------------
# read and process sch file for components and write to output file
def parseSch(): # and write to file
  global line, warning

  try:
    with open(filesch, 'r') as fin:
      with open(filenet, 'w') as fout:

        # skip lines before components start
        line = '~'; lineno = 0
        while line[:12] != '<Components>' and line != '':# and lineno < 1000:
          line = fin.readline();  lineno += 1
    
        # read line until components end or > 1000 lines
        while line != '': #and lineno < 1000:
          line = fin.readline(); lineno += 1
          if line[:13] == '</Components>':
            break
          line = line[3:-2] #remove '  <' and '>\n'
          line = shlex.split(line)   # put into fields on ' ' and stripping double-quotes
          lineout = checkComponents() # was parsesch in 0.0.5
          if lineout != None:
            fout.write(lineout)
      return True      
  except:
    messagebox.showinfo('Error', 'Failed to read schematic file.')
    return False  
    
#-------------------------------------------------------------------------------
def appendPin(net, pin):
  global nets

  foundnet = False
  for sublist in nets:
    if sublist[0] == net:
      foundnet = True
  if not foundnet: # net not found, so add a new row for it
    nets.append([net])
  
  # look for net, find it and add pin
  for sublist in nets:
    if sublist[0] == net:
      sublist.append(pin)
      break
      
#-------------------------------------------------------------------------------
def parseSim():
  # inactive components don't get into sim file

  pname = line[1]; pqucs = line[0]
  fieldtotal = len(line)
  
  if pname in components:
    validnet = []
    for fno in range (2,fieldtotal): # skip the first 2 irrelevant fields
      # find all the pins in the line
      if '=' not in line[fno]:
        if line[fno] not in validnet: # to avoid transistors with 4 pins
          validnet.append(line[fno])
          pin = line[1]+'-'+str(fno-1) #take 1 from fno because 0 and 1 have other data
          appendPin(line[fno], pin)  # add pin connection to net

# ----------------------- Net Building -----------------------
def readSim():
  global line
  # process simfile to create nets
  
  # find last .Def:End to give number of lines to skip 
  with open(filesim, 'r') as fin:
    line='~'; lineno = 0; skip = 0
    while line != '' and lineno < 1000:
      line = fin.readline();  lineno += 1
      if '.Def:End' in line:
        skip = lineno

    #read sim file and compile list of nets
    with open(filesim, 'r') as fin:
      # skip the .def lines
      line = '~'; lineno = 0
      while line != '' and lineno < skip:
        line = fin.readline();  lineno += 1

      # read line until components end or > 1000 lines
      while line != '' and lineno < 1000:
        line = fin.readline(); lineno += 1
        if line[0:1] != '.' and line[0:1] != ' ' and line.find(':') > -1 and line.find(' ') > line.find(':'):                     # its a component line
          line = line[:-1]                  # remove \n      
          line = line.replace(':', ' ', 1)  # remove colon marker in components
          line = shlex.split(line)          # put into fields on ' ' and strip '
          parseSim()
          
#---------------------------------------------------------------------------------
# check whether a valid sim file exists and if not, create one if qucs is available
def validSim():
  global warning
  
  if not os.path.isfile(filesim): 
    # no valid sim file exists so try to create one
    # -n = no terminal, -i = inputfile, -o = outputfile
    command = 'qucs-s -n -i ' + filesch + ' -o ' + filesim
    try:
      result = os.system(command)
    except:  
      try:
        command = 'flatpak run io.github.ra3xdh.qucs_s -n -i ' + filesch + ' -o ' + filesim     
        result = os.system(command)
      except:
        pass
          
  # check whether a valid sim file exists now
  if os.path.isfile(filesim):
    try:
      with open(filesim, 'r') as fin:  
        try:
          line = fin.readline()
          if line[:6] == '# Qucs':
            readSim() # input simulation file
          else:          
            messagebox.showinfo('Info', 'The Qucs simulation file is invalid. There will be no net data.');
            return False 
        except:
          messagebox.showinfo('Info', 'Cannot read the Qucs simulation file. There will be no net data.')
          return False
    except:
      messagebox.showinfo('Info', 'Cannot open the Qucs simulation file. There will be no net data.')
      return False
  else:
    messagebox.showinfo('Info', 'Cannot find a Qucs simulation file. There will be no net data.') 
    
  return True
  
# ----------------------- Output Modules -----------------------
#def writeDIYLC(filename: Path):
def writeDIYLC(oksim):

  # ---- components ---- # Still done in parseSch #
  '''CGPT This would be better as it keeps values seperate
  for name, footprint, value in components:
    f.write('[\n')
    f.write(f'{name}\n')
    f.write(f'{footprint}\n')
    f.write(f'{value}\n\n\n')
    f.write(']\n')
  '''

  # ---- nets ----
  '''CGPT
  for net in nets:
   f.write('(\n')
   f.write(f'_net{net[0]}\n')
   for pin in net[1:]:
     f.write(f'{pin}\n')
     f.write(')\n')
  '''   
  # append net lines to net file

  if oksim:
    with open(filenet, 'a') as fout:
      for netno in range (0, len(nets)):
        line = nets[netno]
        fout.write('(\n')
        for pinno in range (0, len(line)):
          fout.write(line[pinno]+'\n')
        fout.write(')\n')
         
# ----------------------- Main GUI -----------------------
def main():
  global warning, filesim, filesch, filenet
   
  root = tk.Tk()
  root.title('Netlist Builder for Qucs ' + version)
  root.geometry('700x550')
    
  showHelp(root)

  success = loadParts()
  if not success: 
    return

  # input file selection
  path = chooseFile(root)
  if not path:
    return

  filesch = str(path)
  directory = path.parent ; filename = path.stem #ext =  path.suffix 
  filesim = str(directory) + '/' + str(filename)  + '.sim'
  filenet = str(directory) + '/' + str(filename)  + '.net'
  
  # Process schematic
  success = parseSch()
  if not success:
    return
    
  oksim = validSim() # was sim_valid in 0.0.5
    
  writeDIYLC(oksim)

  warning = 'Created ' + filenet + '\n\n' + warning  
  messagebox.showinfo('Information', warning)
        
  root.mainloop()

if __name__ == '__main__':
  main()
    


