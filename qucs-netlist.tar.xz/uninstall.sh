#!/bin/bash

echo "Removing qucs-netlist"

sudo rm /usr/local/bin/qucs-netlist
sudo rm /usr/local/share/applications/qucs-netlist.desktop
#sudo rm /usr/local/share/icons/hicolor/64x64/apps/qucs-netlist.png
sudo rm /usr/local/share/icons/hicolor/128x128/apps/qucs-netlist.png
sudo rm /usr/local/share/qucs-netlist/qucs-netlist.py
sudo rm /usr/local/share/qucs-netlist/qucs-netlist.hlp
sudo rm /usr/local/share/qucs-netlist/qucs-netlist.dat

sudo rmdir /usr/local/share/qucs-netlist

echo "Removal complete."

