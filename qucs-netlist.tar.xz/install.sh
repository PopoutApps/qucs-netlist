#!/bin/bash
set -e # exit on failure
echo "Installing qucs-netlist"

sudo mkdir -p /usr/local/share/qucs-netlist
#sudo mkdir -p /usr/local/share/icons/hicolor/64x64/apps
sudo mkdir -p /usr/local/share/icons/hicolor/128x128/apps

sudo cp -p qucs-netlist /usr/local/bin
sudo chmod +x /usr/local/bin/qucs-netlist

sudo cp -p qucs-netlist.py /usr/local/share/qucs-netlist
sudo chmod +x /usr/local/share/qucs-netlist/qucs-netlist.py

sudo cp -p qucs-netlist.desktop /usr/local/share/applications
sudo chmod +x /usr/local/share/applications/qucs-netlist.desktop

#sudo cp -p qucs-netlist64.png /usr/local/share/icons/hicolor/64x64/apps/qucs-netlist.png
sudo cp -p qucs-netlist128.png /usr/local/share/icons/hicolor/128x128/apps/qucs-netlist.png
sudo cp -p qucs-netlist.hlp /usr/local/share/qucs-netlist
sudo cp -p qucs-netlist.dat /usr/local/share/qucs-netlist

echo "Installation complete, if you restart your computer, Qucs-netlist should be in your applications menu."

